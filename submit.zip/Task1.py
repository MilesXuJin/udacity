
import csv
with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)

def sum_telephone(texts,calls):
    number_text_call = []

    for text in texts:
        if text[0] and text[1]not in number_text_call:
            number_text_call.append(text[0])
            number_text_call.append(text[1])
    for call in calls:
        if call[0]and call[1] not in number_text_call:
            number_text_call.append(call[0])
            number_text_call.append(call[1])
    sum_number = "There are {} different telephone numbers in the records.".format( len(number_text_call))
    print(sum_number)

sum_telephone(texts,calls)
