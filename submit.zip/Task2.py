
import csv

with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)

def dic_calls(calls):
    dic_calls = {}
    for call in calls:
        int_call_time = int(call[3])
        if call[0] not in dic_calls.keys():
            dic_calls[call[0]] = int_call_time
        else:
            dic_calls[call[0]] += int_call_time
    return dic_calls

def max_call(calls):
    max_call = max(dic_calls(calls).values())
    for dic_call in dic_calls(calls):
        if dic_calls(calls).get(dic_call) == max_call:
            print("{} spent the longest time, {} seconds, on the phone during September 2016.".format(dic_call,max_call))
            break

max_call(calls)
