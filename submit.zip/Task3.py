
import csv

with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)

def landline_Bangalore(calls):
    landline_Bangalore = []
    for call in calls:
        if call[0].find("(080)") != -1:
            if call[0] not in landline_Bangalore:
                landline_Bangalore.append(call[0])
    landline_Bangalore.sort()
    for call in landline_Bangalore:
        print ("The numbers called by people in Bangalore have codes:{}\n".format(call))

landline_Bangalore(calls)

def percentage_Bangalore(calls):
    all_landline_B = 0
    for call in calls:
        if (call[0].find("(080)") != -1) and (call[1].find("(080)") != -1):
            all_landline_B += 1
    percentage = float(all_landline_B / len(calls))
    print("{}% percent of calls from fixed lines in Bangalore are calls to other fixed lines in Bangalore.".format('%.2f' %((all_landline_B / len(calls))*100)))

percentage_Bangalore(calls)
