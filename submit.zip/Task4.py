import csv

with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)

def find_telemarketers(calls,texts):
    telemarketers_calls = set()
    for call in calls:
        for text in texts:
            if (call[0] not in text[0]) and (call[0] not in text[1]) and (call[0] not in call[1]):
                telemarketers_calls.add(call[0])
    for tele_call in telemarketers_calls:
        print("These numbers could be telemarketers: " + tele_call + "\n")

find_telemarketers(calls,texts)
